"""Hard-coded catalog of CS2 skins for demonstration.

This module defines a nested dictionary representing categories, weapons,
skins and available wears. In a production scenario, this data should come
from a database or a static file, but for the MVP it's fine to hard-code
a few popular examples.
"""

Catalog: dict[str, dict[str, dict[str, list[str]]]] = {
    "Rifles": {
        "AK-47": {
            "Fuel Injector": [
                "Factory New",
                "Minimal Wear",
                "Field-Tested",
                "Well-Worn",
                "Battle-Scarred",
            ],
            "Redline": [
                "Factory New",
                "Minimal Wear",
                "Field-Tested",
                "Well-Worn",
                "Battle-Scarred",
            ],
        },
        "M4A1-S": {
            "Hot Rod": [
                "Factory New",
            ],
            "Golden Coil": [
                "Factory New",
                "Minimal Wear",
                "Field-Tested",
            ],
        },
    },
    "Pistols": {
        "Desert Eagle": {
            "Blaze": ["Factory New", "Minimal Wear"],
            "Printstream": ["Factory New", "Minimal Wear", "Field-Tested"],
        },
    },
}