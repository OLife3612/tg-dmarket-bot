"""Handler for listing tracked skins and calculating the total value."""

from decimal import Decimal
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from ..dmarket_client import DMarketClient
from ..repo import get_items_for_user

router = Router()


@router.message(Command("skins"))
async def cmd_skins(message: Message) -> None:
    """Show the list of tracked items with their current prices and total."""
    # Retrieve items from DB
    items = [row async for row in get_items_for_user(message.from_user.id)]
    if not items:
        await message.answer("У вас нет отслеживаемых предметов. Добавьте их командой /add.")
        return
    client = DMarketClient()
    lines: list[str] = []
    total = Decimal("0")
    for market_hash_name, display_name, target_price in items:
        price, currency = await client.get_best_price(market_hash_name)
        total += price
        lines.append(f"{display_name} — {price} {currency}")
    # Close the client session
    await client.close()
    # Build response
    response = "\n".join(lines)
    response += f"\n\n<b>Итого:</b> {total} USD"
    await message.answer(response)