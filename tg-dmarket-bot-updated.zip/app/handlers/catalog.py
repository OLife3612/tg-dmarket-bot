"""Handlers for browsing a catalog of skins via inline buttons."""

from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

from ..catalog import Catalog
from ..repo import add_item_for_user

router = Router()


def build_market_hash_name(weapon: str, skin: str, wear: str) -> str:
    """Generate a simplified market hash name from weapon, skin and wear."""
    return (
        f"{weapon} {skin} {wear}"
        .lower()
        .replace(" ", "-")
        .replace("--", "-")
    )


@router.message(Command("catalog"))
async def cmd_catalog(message: Message) -> None:
    """Send the top-level categories for the catalog."""
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=category, callback_data=f"cat:{category}")]
            for category in Catalog.keys()
        ]
    )
    await message.answer("Выберите категорию оружия:", reply_markup=keyboard)


@router.callback_query(F.data.startswith("cat:"))
async def on_category(callback: CallbackQuery) -> None:
    category = callback.data.split(":", 1)[1]
    weapons = Catalog.get(category, {})
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=weapon, callback_data=f"weap:{category}|{weapon}")]
            for weapon in weapons.keys()
        ]
        + [[InlineKeyboardButton(text="⬅️ Назад", callback_data="back:root")]]
    )
    await callback.message.edit_text(
        f"{category}: выберите оружие:", reply_markup=keyboard
    )


@router.callback_query(F.data.startswith("weap:"))
async def on_weapon(callback: CallbackQuery) -> None:
    _, payload = callback.data.split(":", 1)
    category, weapon = payload.split("|", 1)
    skins = Catalog.get(category, {}).get(weapon, {})
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=skin, callback_data=f"skin:{category}|{weapon}|{skin}"
                )
            ]
            for skin in skins.keys()
        ]
        + [[InlineKeyboardButton(text="⬅️ Назад", callback_data=f"cat:{category}")]]
    )
    await callback.message.edit_text(
        f"{weapon}: выберите скин:", reply_markup=keyboard
    )


@router.callback_query(F.data.startswith("skin:"))
async def on_skin(callback: CallbackQuery) -> None:
    _, payload = callback.data.split(":", 1)
    category, weapon, skin = payload.split("|", 2)
    wears = Catalog.get(category, {}).get(weapon, {}).get(skin, [])
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=wear,
                    callback_data=f"wear:{category}|{weapon}|{skin}|{wear}",
                )
            ]
            for wear in wears
        ]
        + [[InlineKeyboardButton(text="⬅️ Назад", callback_data=f"weap:{category}|{weapon}")]]
    )
    await callback.message.edit_text(
        f"{skin}: выберите качество:", reply_markup=keyboard
    )


@router.callback_query(F.data.startswith("wear:"))
async def on_wear(callback: CallbackQuery) -> None:
    _, payload = callback.data.split(":", 1)
    category, weapon, skin, wear = payload.split("|", 3)
    # Build and add item
    market_hash_name = build_market_hash_name(weapon, skin, wear)
    display_name = f"{weapon} | {skin} ({wear})"
    await add_item_for_user(
        tg_user_id=callback.from_user.id,
        market_hash_name=market_hash_name,
        display_name=display_name,
    )
    await callback.answer(text=f"Добавлено: {display_name}", show_alert=True)
    # Reset to root after adding
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=category, callback_data=f"cat:{category}")]
            for category in Catalog.keys()
        ]
    )
    await callback.message.edit_text(
        "Предмет добавлен. Выберите категорию для добавления ещё:",
        reply_markup=keyboard,
    )


@router.callback_query(F.data == "back:root")
async def on_back_root(callback: CallbackQuery) -> None:
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=category, callback_data=f"cat:{category}")]
            for category in Catalog.keys()
        ]
    )
    await callback.message.edit_text(
        "Выберите категорию оружия:", reply_markup=keyboard
    )