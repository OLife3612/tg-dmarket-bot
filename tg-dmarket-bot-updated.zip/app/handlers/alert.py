"""Handler for managing price alerts."""

from decimal import Decimal
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from ..repo import set_target_price

router = Router()


@router.message(Command("alert"))
async def cmd_alert(message: Message) -> None:
    """Set or remove a price alert for an item.

    Usage: /alert <market_hash_name> <price>

    If price is omitted or non-numeric, the alert will be cleared for that item.
    """
    if not message.text:
        return
    parts = message.text.split(maxsplit=2)
    if len(parts) < 2:
        await message.answer(
            "Использование: /alert <item_id> <цена>. Например:\n"
            "/alert ak-47-fuel-injector-minimal-wear 100"
        )
        return
    market_hash_name = parts[1]
    target: float | None = None
    if len(parts) >= 3:
        try:
            target = float(parts[2].replace(",", "."))
        except ValueError:
            target = None
    await set_target_price(message.from_user.id, market_hash_name, target)
    if target is None:
        await message.answer(
            f"Алерт для {market_hash_name} удалён (или не установлен корректно)."
        )
    else:
        await message.answer(
            f"Алерт для {market_hash_name} установлен: цена ≤ {target} USD."
        )