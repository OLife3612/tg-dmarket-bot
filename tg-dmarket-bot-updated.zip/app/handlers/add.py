"""Handler for adding items to track via a link."""

import re
from urllib.parse import urlparse, parse_qs

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from ..repo import add_item_for_user

router = Router()


DMARKET_HOSTS = {"dmarket.com", "www.dmarket.com"}


def extract_market_hash_name(url: str) -> str | None:
    """Attempt to derive a market identifier from a DMarket item URL.

    This function parses the URL path and query parameters to extract a stable
    identifier for the item. DMarket item URLs typically include the item
    name and wear in the path, but the actual identifier used by the API may
    differ. For now, we return the full path without the domain as a
    placeholder.

    Args:
        url: The user provided URL to an item on DMarket.

    Returns:
        A string representing the market hash name or None if the URL does
        not look like a DMarket item link.
    """
    try:
        parsed = urlparse(url)
    except Exception:
        return None
    if parsed.netloc.lower() not in DMARKET_HOSTS:
        return None
    # For example: /marketplace/items/csgo-tesla-ak-47-fuel-injector
    path_parts = [part for part in parsed.path.split("/") if part]
    if not path_parts:
        return None
    # Use the last segment as the identifier. This is a simplification.
    return path_parts[-1]


@router.message(Command("add"))
async def cmd_add(message: Message) -> None:
    """Parse a DMarket link from the message and add the item to the DB."""
    if not message.text:
        return
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        await message.answer(
            "Пожалуйста, укажите ссылку на предмет после команды, например:\n"
            "/add https://dmarket.com/marketplace/items/your-item-id"
        )
        return
    url = parts[1].strip()
    market_hash_name = extract_market_hash_name(url)
    if not market_hash_name:
        await message.answer(
            "Не удалось распознать ссылку. Убедитесь, что это ссылка на DMarket."
        )
        return
    # Use the identifier as a human-friendly display name for now
    display_name = market_hash_name.replace("-", " ")
    await add_item_for_user(
        tg_user_id=message.from_user.id,
        market_hash_name=market_hash_name,
        display_name=display_name,
    )
    await message.answer(f"Добавлен: {display_name}")