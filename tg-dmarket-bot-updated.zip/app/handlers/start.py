"""Handler for the /start command."""

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

router = Router()


@router.message(Command("start"))
async def cmd_start(message: Message) -> None:
    """Send a welcome message and brief instructions."""
    await message.answer(
        "Привет!\n"
        "Добавьте предмет для отслеживания с помощью /add <ссылка> или выберите через каталог.\n"
        "Покажите все отслеживаемые предметы командой /skins."
    )