"""Client wrapper for interacting with the DMarket API.

This module contains a simple asynchronous client that wraps the HTTP
interaction required to query the current market depth for a CS2 item.
You should populate the `get_best_price` method with a real HTTP request
using the DMarket marketplace API once you have an API key.
"""

import os
from decimal import Decimal
from typing import Tuple

import aiohttp


class DMarketClient:
    """A minimal client for querying item prices from DMarket."""

    BASE_URL = "https://api.dmarket.com"

    def __init__(self, api_key: str | None = None) -> None:
        self.api_key = api_key or os.getenv("DMARKET_API_KEY")
        if not self.api_key:
            raise RuntimeError("DMARKET_API_KEY must be provided")
        # aiohttp session will be created lazily
        self._session: aiohttp.ClientSession | None = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                headers={"X-Api-Key": self.api_key},
                raise_for_status=True,
                base_url=self.BASE_URL,
            )
        return self._session

    async def close(self) -> None:
        """Close the underlying HTTP session."""
        if self._session and not self._session.closed:
            await self._session.close()

    async def get_best_price(self, market_hash_name: str) -> Tuple[Decimal, str]:
        """Fetch the current best ask price for a given item.

        Args:
            market_hash_name: The market hash name or identifier for the CS2 item.

        Returns:
            A tuple of (price, currency). Price is a Decimal for precision.

        Note:
            The implementation below is a stub. You should replace the
            `return` line with a real API call to DMarket. For reference,
            consult the official DMarket API documentation and look for
            the `marketplace-api/v1/market-depth` endpoint.
        """
        # TODO: Implement API request to DMarket
        # Example pseudo-code:
        # session = await self._get_session()
        # resp = await session.get(
        #     "/marketplace-api/v1/market-depth",
        #     params={"gameId": "a8db", "types": market_hash_name},
        # )
        # data = await resp.json()
        # Extract the minimum ask and currency from data
        # price = Decimal(data["bestAsk"]["price"])
        # currency = data["bestAsk"]["currency"]
        # return price, currency
        return Decimal("0.00"), "USD"