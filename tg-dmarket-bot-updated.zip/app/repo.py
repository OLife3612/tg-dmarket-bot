"""Database access layer for storing users and their tracked items.

This module uses aiosqlite to persist user data in a SQLite database. It
defines simple functions for creating tables, adding items and retrieving
tracked items for a given user.
"""

import os
from typing import Iterable, Tuple

import aiosqlite


async def init_db() -> None:
    """Initialize the SQLite database if it doesn't already exist."""
    db_path = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///db.sqlite3")
    # Extract the path after the scheme
    if db_path.startswith("sqlite+aiosqlite:///"):
        db_path = db_path.replace("sqlite+aiosqlite:///", "")
    async with aiosqlite.connect(db_path) as db:
        await db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tg_user_id INTEGER UNIQUE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                market_hash_name TEXT NOT NULL,
                display_name TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS user_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                item_id INTEGER NOT NULL,
                target_price REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id),
                FOREIGN KEY(item_id) REFERENCES items(id)
            );
            """
        )
        await db.commit()


async def get_or_create_user(tg_user_id: int) -> int:
    """Ensure a user exists in the database and return their internal ID.

    Args:
        tg_user_id: The Telegram user's unique identifier.

    Returns:
        The database ID of the user.
    """
    db_path = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///db.sqlite3")
    if db_path.startswith("sqlite+aiosqlite:///"):
        db_path = db_path.replace("sqlite+aiosqlite:///", "")
    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            "SELECT id FROM users WHERE tg_user_id = ?", (tg_user_id,)
        ) as cur:
            row = await cur.fetchone()
            if row:
                return row[0]
        # Insert new user
        await db.execute(
            "INSERT INTO users (tg_user_id) VALUES (?)", (tg_user_id,)
        )
        await db.commit()
        return await get_or_create_user(tg_user_id)


async def add_item_for_user(
    tg_user_id: int, market_hash_name: str, display_name: str, target_price: float | None = None
) -> None:
    """Add a tracked item for the given user.

    Args:
        tg_user_id: Telegram user ID.
        market_hash_name: The unique identifier used by DMarket for the item.
        display_name: Human-friendly name of the item (weapon and skin).
        target_price: Optional alert threshold.
    """
    user_id = await get_or_create_user(tg_user_id)
    db_path = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///db.sqlite3")
    if db_path.startswith("sqlite+aiosqlite:///"):
        db_path = db_path.replace("sqlite+aiosqlite:///", "")
    async with aiosqlite.connect(db_path) as db:
        # Ensure item exists
        async with db.execute(
            "SELECT id FROM items WHERE market_hash_name = ?", (market_hash_name,)
        ) as cur:
            row = await cur.fetchone()
            if row:
                item_id = row[0]
            else:
                cur2 = await db.execute(
                    "INSERT INTO items (market_hash_name, display_name) VALUES (?, ?)",
                    (market_hash_name, display_name),
                )
                await db.commit()
                item_id = cur2.lastrowid
        # Link to user
        await db.execute(
            "INSERT INTO user_items (user_id, item_id, target_price) VALUES (?, ?, ?)",
            (user_id, item_id, target_price),
        )
        await db.commit()


async def get_items_for_user(tg_user_id: int) -> Iterable[Tuple[str, str, float | None]]:
    """Retrieve all tracked items for a user.

    Returns:
        An iterable of (market_hash_name, display_name, target_price) tuples.
    """
    user_id = await get_or_create_user(tg_user_id)
    db_path = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///db.sqlite3")
    if db_path.startswith("sqlite+aiosqlite:///"):
        db_path = db_path.replace("sqlite+aiosqlite:///", "")
    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            """
            SELECT items.market_hash_name, items.display_name, user_items.target_price
            FROM user_items
            JOIN items ON items.id = user_items.item_id
            WHERE user_items.user_id = ?
            ORDER BY user_items.id
            """,
            (user_id,),
        ) as cur:
            rows = await cur.fetchall()
            for row in rows:
                yield row


async def set_target_price(
    tg_user_id: int, market_hash_name: str, target_price: float | None
) -> None:
    """Set an alert threshold for a given user's item.

    If the item is not yet tracked by the user, this function does nothing.

    Args:
        tg_user_id: Telegram user ID.
        market_hash_name: Identifier of the item.
        target_price: Threshold value in USD; if None, the alert will be cleared.
    """
    user_id = await get_or_create_user(tg_user_id)
    db_path = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///db.sqlite3")
    if db_path.startswith("sqlite+aiosqlite:///"):
        db_path = db_path.replace("sqlite+aiosqlite:///", "")
    async with aiosqlite.connect(db_path) as db:
        # find item id by market_hash_name
        async with db.execute(
            "SELECT id FROM items WHERE market_hash_name = ?", (market_hash_name,)
        ) as cur:
            row = await cur.fetchone()
            if not row:
                # nothing to update
                return
            item_id = row[0]
        await db.execute(
            "UPDATE user_items SET target_price = ? WHERE user_id = ? AND item_id = ?",
            (target_price, user_id, item_id),
        )
        await db.commit()


async def get_items_with_alerts() -> Iterable[Tuple[int, str, str, float]]:
    """Retrieve all user items with a target price set.

    Returns:
        Iterable of tuples (tg_user_id, market_hash_name, display_name, target_price).
    """
    db_path = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///db.sqlite3")
    if db_path.startswith("sqlite+aiosqlite:///"):
        db_path = db_path.replace("sqlite+aiosqlite:///", "")
    async with aiosqlite.connect(db_path) as db:
        async with db.execute(
            """
            SELECT users.tg_user_id, items.market_hash_name, items.display_name, user_items.target_price
            FROM user_items
            JOIN users ON users.id = user_items.user_id
            JOIN items ON items.id = user_items.item_id
            WHERE user_items.target_price IS NOT NULL
            """
        ) as cur:
            rows = await cur.fetchall()
            for row in rows:
                yield row