# This package contains the Telegram bot application modules.

from .main import run

__all__ = ["run"]