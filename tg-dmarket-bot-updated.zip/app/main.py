"""Entry point for the Telegram bot.

This module wires up the aiogram dispatcher, registers command handlers and
starts polling. Configuration values are taken from environment variables.
"""

import asyncio
import os
from aiogram import Bot, Dispatcher
from aiogram.types import BotCommand
from aiogram import F

from .handlers.start import router as start_router
from .handlers.add import router as add_router
from .handlers.skins import router as skins_router
from .handlers.catalog import router as catalog_router
from .handlers.alert import router as alert_router
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from decimal import Decimal
from .repo import get_items_with_alerts, set_target_price
from .dmarket_client import DMarketClient


async def register_commands(bot: Bot) -> None:
    """Set the list of commands shown in the bot's command menu.

    Args:
        bot: The aiogram Bot instance.
    """
    commands = [
        BotCommand(command="start", description="Запустить бота и получить приветствие"),
        BotCommand(command="add", description="Добавить предмет по ссылке"),
        BotCommand(command="catalog", description="Выбрать предмет из каталога"),
        BotCommand(command="skins", description="Показать отслеживаемые предметы"),
        BotCommand(command="alert", description="Установить или снять алерт"),
    ]
    await bot.set_my_commands(commands)


async def run() -> None:
    """Configure and start the aiogram polling application."""
    token = os.getenv("BOT_TOKEN")
    if not token:
        raise RuntimeError("BOT_TOKEN environment variable must be set")
    bot = Bot(token=token, parse_mode="HTML")
    # Initialize the database (create tables if missing)
    from .repo import init_db
    await init_db()

    # Set up scheduler for price alerts
    scheduler = AsyncIOScheduler()

    async def check_alerts() -> None:
        """Check items with alerts and notify users if conditions are met."""
        client = DMarketClient()
        async for tg_user_id, market_hash_name, display_name, target_price in get_items_with_alerts():
            price, currency = await client.get_best_price(market_hash_name)
            # If target_price is None, skip
            if target_price is not None:
                try:
                    threshold = Decimal(str(target_price))
                except Exception:
                    continue
                if price <= threshold:
                    await bot.send_message(
                        tg_user_id,
                        f"🔔 Цена на {display_name} достигла {price} {currency} (≤ {threshold})",
                    )
                    # Remove alert after notification
                    await set_target_price(tg_user_id, market_hash_name, None)
        await client.close()

    # Run the alert check every 5 minutes
    scheduler.add_job(check_alerts, "interval", minutes=5)
    scheduler.start()
    dp = Dispatcher()
    # Register routers
    dp.include_router(start_router)
    dp.include_router(add_router)
    dp.include_router(skins_router)
    dp.include_router(catalog_router)
    dp.include_router(alert_router)
    # Register commands menu
    await register_commands(bot)
    # Start polling
    await dp.start_polling(bot)


def main() -> None:
    """Synchronously run the async entry point."""
    try:
        asyncio.run(run())
    except (KeyboardInterrupt, SystemExit):
        # Graceful shutdown on Ctrl+C
        pass


if __name__ == "__main__":
    main()